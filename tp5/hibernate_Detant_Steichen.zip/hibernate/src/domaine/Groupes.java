package domaine;

import domaine.base.BaseGroupes;



public class Groupes extends BaseGroupes {
	private static final long serialVersionUID = 1L;

/*[CONSTRUCTOR MARKER BEGIN]*/
	public Groupes () {
		super();
	}

	/**
	 * Constructor for primary key
	 */
	public Groupes (java.lang.Integer id) {
		super(id);
	}

/*[CONSTRUCTOR MARKER END]*/


}