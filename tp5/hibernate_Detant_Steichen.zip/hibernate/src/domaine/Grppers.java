package domaine;

import domaine.base.BaseGrppers;



public class Grppers extends BaseGrppers {
	private static final long serialVersionUID = 1L;

/*[CONSTRUCTOR MARKER BEGIN]*/
	public Grppers () {
		super();
	}

	/**
	 * Constructor for primary key
	 */
	public Grppers (java.lang.Integer id) {
		super(id);
	}

/*[CONSTRUCTOR MARKER END]*/


}